
#' Process an MRM file in total
#'
#' This is a convenience function that performs an end to end analysis of an
#' Sciex MRM run; it can be used when the intermediate data structures (total
#' ion chromatograms, shot lists, .wiff file readers) are not required.
#'
#' @param wiffFile A valid file path to the Sciex data file (extension .wiff)
#' containing the metadata for one or more EchoMS runs
#' @param wiffScanFile An valid file path the the Sciex scan file (extension
#' .wiff.scan) containing the full raw EchoMS data
#' @param ... Additional optional parameters to be passed to [measurePeaks()]
#'
#' @return A list containing two data frames: `peaks`, with all extracted TIC
#' peaks for all runs, as output by [measurePeaks()], and `massAreas`,
#' containing the measured areas for all mass transitoins and all peaks in all
#' runs, as output by [getMRMAreas()].  Both data frames contain an addtional
#' `sample` column indicating which run within the file the values were
#' extracted from.
#' @export
#'
#' @examples
processAllMRMAreas <- function(wiffFile,wiffScanFile,...) {
	wiff <- newWiffReader(wiffFile,wiffScanFile)
	shots <- getWiffShots(wiff)
	tics <- getAllTIC(wiff)

	peakdf <- data.frame()
	massdf <- data.frame()
	for (si in seq_along(wiff$samples)) {
		cursample <- paste0("Sample",si)
		peaks <- measurePeaks(tics[[si]],shots,...)
		peaks$sample <- cursample
		peakdf <- rbind(peakdf,peaks)

		massarea <- getMRMAreas(wiffScanFile,tics[[si]],wiff$samples[[si]],peaks)
		massarea$sample <- cursample
		massdf <- rbind(massdf,massarea)
	}

	list(peaks=peakdf,massAreas=massdf)
}

#' Extract the peak areas for MRM mass transitions
#'
#' @param scanfile A file path to a Sciex raw scan file (extension .wiff.scan)
#' containing the raw data referenced by the .wiff file from which the other
#' parameters were extracted
#' @param tic A total ion chromatogram data.frame as extracted by [getTIC()] or
#' [getAllTIC()]
#' @param sample A "sample" object representing a run in a .wiff file, from the
#' `samples` field of an `rtmsWiffReader` object, containing information about
#' the mass transitions measured in that run
#' @param peaks A peak table listing the timing and boundaries of the total ion
#' chromatogram peaks for all shots in the run, as returned by [measurePeaks()]
#'
#' @return A data frame containing the total intensity for each mass transition
#' and each peak; see Details for column specifics.
#'
#' @details
#' The table return includes a measurement of total area for each of the mass
#' transitions listed in `sample`.  It contains one row for each measured shot
#' each mass transition, with the following columns:
#' * `shotorder`: The order of the peak within the shots fired during the run
#' * `well`: The alphanumeric well name of the well from which the shot was
#' fired
#' * `time`: The time (in seconds) after the beginning of the run at which the
#' intensity from the shot was at its peak
#' * `mass`: The name of the mass transition measured (often a compound name or
#' id)
#' * `area`: The intensity area (in counts) for that particular mass transition
#' from that shot's peak
#'
#' @export
#'
#' @examples
getMRMAreas <- function(scanfile,tic,sample,peaks) {
	numMasses <- length(sample$masses)
	chroma <- getMRMChromatograms(scanfile,tic,sample)

	meanstep <- mean(diff(tic$time))
	tic$step <- c(diff(tic$time),meanstep)

	areadf <- data.frame()
	for (miter in seq_len(numMasses)) {
		peakvec <- rep(NA,nrow(peaks))
		for (piter in seq_len(nrow(peaks))) {
			rel <- tic$time >= peaks$minTime[[piter]] & tic$time<= peaks$maxTime[[piter]]
			peakvec[[piter]] <- sum(tic$step[rel]*chroma[rel,miter])
		}
		areadf <- rbind(areadf,data.frame(shotorder=peaks$shotorder,
										  well=peaks$well,
										  time=peaks$time,
										  mass=sample$masses[[miter]],
										  area=peakvec))
	}
	areadf
}

getMRMChromatograms <- function(scanfile,tic,sample) {
	numMasses <- length(sample$masses)
	tic <- tic[order(tic$offset),]
	if (any(tic$size != 4*numMasses)) {
		stop("All MRM scans should be represented as blocks of 4-byte floating point numbers.")
	}
	numPoints <- nrow(tic)
	blockSize <- tic$offset[[numPoints]] + tic$size[[numPoints]]

	scon <- file(scanfile,"rb")
	on.exit({ close(scon) }, add=TRUE)
	seek(scon,sample$offset)
	seek(scon,12,origin="current")
	blockSizeCheck <- readBin(scon,"integer",1,size=4,endian="little")
	if (blockSize!=blockSizeCheck) {
		stop("Scan file block size does not match wiff file data.")
	}
	seek(scon,8,origin="current")
	dataBlock <- t(array(readBin(scon,"double",numPoints*numMasses,size=4,endian="little"),
						 dim=c(numMasses,numPoints)))
	dataBlock
}
