#' Get the total area for given masses in a particular time range
#'
#' @param scanfile A file path to a Sciex raw scan file (extension .wiff.scan)
#' containing the raw data referenced by the .wiff file from which the other
#' parameters were extracted
#' @param ptic A (possibly partial) total ion chromatogram of the format output
#' by [getTIC()] or [getAllTIC()] referring to the range of timepoints to be
#' extracted
#' @param sample The particular object from the `samples` field of the
#' `rtmsWiffReader` object, which in this case contains binary offsets into the
#' .wiff.scan file
#' @param peaks A list of peak objects of class `rtmsPeak`
#'
#' @return A data.frame of measurements for each peak; see
#' [rtms::measureSample()] for format details
#' @export
#'
#' @examples
getFullScanAreas <- function(scanfile,ptic,sample,peaks) {
	spectrum <- getFullScanSpectrum(scanfile,ptic,sample)
	rtms::measureSample(rtms::getSample(spectrum,peaks,freqSpacing=FALSE),"PeakArea")
}

#' Extract a full mass spectrum for a given full-scan shot
#'
#' @param scanfile A file path to a Sciex raw scan file (extension .wiff.scan)
#' containing the raw data referenced by the .wiff file from which the other
#' parameters were extracted
#' @param ptic A partial total ion chromatogram of the format output by
#' [getTIC()] or [getAllTIC()] referring to the range of timepoints to be
#' extracted
#' @param sample The particular object from the `samples` field of the
#' `rtmsWiffReader` object, which in this case contains binary offsets into the
#' .wiff.scan file
#'
#' @return A spectrum object of class `rtmsSpectrum`
#' @export
#'
#' @examples
getFullScanSpectrum <- function(scanfile,ptic,sample) {
	spectra <- getFullScanData(scanfile,ptic,sample,removeZeros=FALSE)
	specsum <- data.frame(mz=unique(spectra$mz),area=NA)
	for (si in seq_len(nrow(specsum))) {
		specsum$area[[si]] <- sum(spectra$intensity[spectra$mz==specsum$mz[[si]]])
	}

	rtms::rtmsSpectrum(specsum$mz,specsum$area)
}

#' Extract raw Wiff full scan data
#'
#' @param scanfile A file path to a Sciex raw scan file (extension .wiff.scan)
#' containing the raw data referenced by the .wiff file from which the other
#' parameters were extracted
#' @param ptic A (possibly partial) total ion chromatogram of the format output
#' by [getTIC()] or [getAllTIC()] referring to the range of timepoints to be
#' extracted
#' @param sample The particular object from the `samples` field of the
#' `rtmsWiffReader` object, which in this case contains binary offsets into the
#' .wiff.scan file
#' @param removeZeros If `FALSE` (the default) all intensity measuremens for
#' all time points and m/z values will be extractd and returned; if `TRUE`,
#' only values greater than zero will be returned; this can result in a much
#' smaller output and may be useful for calculating areas
#'
#' @return A data frame containing all raw data for the given range (see
#' Details)
#'
#' @details
#' The data frame output by the function contains all the intensity data
#' compressed into the .wiff.scan file for the given range of times; it has the
#' following columns:
#' * `index`: The particular row of `ptic` the measurement corresponds to
#' * `time`: The time (in seconds) after the beginning of the run at which the
#' measurement was taken
#' * `mz`: The mass to charge value (in m/z) which the measurement corresponds
#' to
#' * `intensity`: The intensity (in counts per second) that was measured for
#' the given time and m/z value
#'
#' @export
#'
#' @examples
getFullScanData <- function(scanfile,ptic,sample,removeZeros=FALSE) {
	scon <- file(scanfile,"rb")
	on.exit(close(scon))
	getFullScanData_internal(scon,ptic,sample,removeZeros)
}

getFullScanData_internal <- function(scon,ptic,sample,removeZeros=FALSE) {
	rawvecs <- list()
	baseoffset <- sample$offset+24
	for (titer in seq_len(nrow(ptic))) {
		seek(scon,baseoffset+ptic$offset[titer])
		rawvecs[[titer]] <- readBin(scon,"raw",ptic$size[titer])
	}

	specs <- list()
	for (titer in seq_len(nrow(ptic))) {
		curdf <- wfs_parseSpectrum(rawvecs[[titer]])
		curdf$index <- titer
		curdf$time <- ptic$time[[titer]]
		if (removeZeros) {
			curdf <- curdf[curdf$intensity>0,]
		}
		specs[[titer]] <- curdf
	}

	return(do.call(rbind,specs))
}

wfs_parseSpectrum <- function(rawvec) {
	if (length(rawvec)<=44 || (length(rawvec)%%4)!=0) {
		stop("Compressed spectrum blocks must be a multiple of 4 bytes greater than 44.")
	}
	if (any(readBin(rawvec[1:8],"integer",2,size=4,endian="little")!=c(-2,1))) {
		stop("Compressed spectrum blocks must begin with a -2, 1 marker.")
	}
	params <- readBin(rawvec[9:40],"double",4,size=8,endian="little")
	lower <- params[[1]]
	upper <- params[[2]]
	step <- params[[3]]
	multiple <- params[[4]]
	npeaks <- readBin(rawvec[41:44],"integer",1,size=4,endian="little")

	specdf <- data.frame(mz=seq(lower,upper,by=step),intensity=0)
	if (npeaks==0) { return(specdf) }

	subvec <- rawvec[45:(length(rawvec))]
	valdf <- wfs_extractBlockValues(subvec,npeaks)
	specdf$intensity[(valdf$val1)+1] <- multiple*valdf$val2
	return(specdf)
}

wfs_extractBlockValues <- function(rawvec,npeaks) {
	peaks <- data.frame(val1=rep(1,npeaks),val2=NA)
	peakIndex <- 1
	val1 <- c()
	val2 <- c()
	type1 <- c()

	rawcon <- rawConnection(rawvec,"rb")
	on.exit({ close(rawcon) })

	curval1 <- 0
	curtype1 <- "implicit"

	finished <- FALSE
	while (peakIndex<=npeaks) {
		num <- readBin(rawcon,"integer",1,size=1,signed=FALSE)

		if (num>0) { curstate <- "subbyte" }
		else { curstate <- "fullbyte" }

		while (curstate != "open") {
			if (curstate=="subbyte") {
				seek(rawcon,-1,origin="current")
				allsubs <- c()

				while (!any((allsubs%%8)==0)) {
					num <- readBin(rawcon,"integer",1,size=1,signed=FALSE)
					allsubs <- c(allsubs,wfs_getSubbytes(num))
				}

				for (subindex in seq_along(allsubs)) {
					if ((allsubs[[subindex]]%%8)==0) {
						# A subbyte of 0 or 8 indicates a string of subbyte
						# values is finished. 0 indicates that full bytes
						# are next to be read; 8 indicates that the next stream
						# of bytes is open.
						if (allsubs[[subindex]]==0) { curstate <- "fullbyte" }
						else { curstate <- "open" }
						break
					} else if (allsubs[[subindex]]>8) {
						# A subbyte with value n>8 indicates that (n-8) m/z
						# values are skipped before the next intensity
						peaks$val1[[peakIndex]] <- peaks$val1[[peakIndex]]+allsubs[[subindex]]-8
					} else {
						# A subbyte with value n<8 indicates an intensity of
						# value n; if some m/z values have been skipped this
						# should be tracked; otherwise the m/z is assumed to be
						# immediately after the previous one.
						peaks$val2[[peakIndex]] <- allsubs[[subindex]]
						peakIndex <- peakIndex+1
						if (peakIndex>npeaks) { break }
					}
				}
				if (peakIndex>npeaks) { break }

			} else if (curstate=="fullbyte") {
				num <- readBin(rawcon,"integer",1,size=1,signed=FALSE)

				if (length(num)==0) {
					break
				} else if (num==0) {
					num <- readBin(rawcon,"integer",1,size=4,endian="little")
				}

				peaks$val2[[peakIndex]] <- num
				peakIndex <- peakIndex+1
				if (peakIndex>npeaks) { break }

				num <- readBin(rawcon,"integer",1,size=1,signed=FALSE)

				if (num==128) { curstate <- "open" }
				else if (num==0) { curstate <- "fullbyte" }
				else { curstate <- "subbyte" }
				curtype1 <- "implicit"
			}
		}
		# if (finished) { break }
		if (peakIndex>npeaks) { break }

		num <- readBin(rawcon,"integer",1,size=1,signed=FALSE)
		if (num==0) {
			nextval <- readBin(rawcon,"integer",1,size=4,endian="little")
			peaks$val1[[peakIndex]] <- peaks$val1[[peakIndex]]+nextval
			curtype1 <- "fullint"
		} else {
			peaks$val1[[peakIndex]] <- peaks$val1[[peakIndex]]+num
			curtype1 <- "byte"
		}
	}

	peaks$val1 <- cumsum(peaks$val1)-1
	return(peaks)
}

wfs_getSubbytes <- function(num) {
	return(c(floor(num/16),num%%16))
}
