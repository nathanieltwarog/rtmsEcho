
# Standard binary function to check a series of binary byts in an open binary
# connection
bin_checkBytes <- function(fcon,bytes,message="Invalid bytes") {
	# Check that the next string of bytes in a file matches a given set
	if (!all(readBin(fcon,"raw",length(bytes))==bytes)) { stop(message) }
}

# Reads the header block of a CFBF binary file
cfbf_readHeader <- function(rcon) {
	on.exit(close(rcon))

	seek(rcon,0)
	# d0 cf 11 e0 a1 b1 1a e1
	bin_checkBytes(rcon,as.raw(c(208, 207, 17, 224, 161, 177, 26, 225)))
	bin_checkBytes(rcon,as.raw(rep(0,16)))
	minorVersion <- readBin(rcon,"integer",1,size=2,signed=FALSE)
	majorVersion <- readBin(rcon,"integer",1,size=2,signed=FALSE)
	bin_checkBytes(rcon,as.raw(c(254,255)))
	sectorSize <- 2^readBin(rcon,"integer",1,size=2,signed=FALSE)
	if (majorVersion==3) {
		stopifnot(majorVersion==3 && sectorSize==512)
	} else if (majorVersion==4) {
		stopifnot(majorVersion==4 && sectorSize==4096)
	} else {
		stopifnot(majorVersion%in%c(3,4))
	}
	minisectorSize <- 2^readBin(rcon,"integer",1,size=2,signed=FALSE)
	stopifnot(minisectorSize==64)
	bin_checkBytes(rcon,as.raw(rep(0,6)))
	dirSize <- readBin(rcon,"integer",1,size=4)
	if (majorVersion==3) {
		stopifnot(majorVersion==3 && dirSize==0)
	}
	fatSectors <- readBin(rcon,"integer",1,size=4)
	stopifnot(fatSectors>0)
	firstDirectorySector <- readBin(rcon,"integer",1,size=4)
	signatureNumber <- readBin(rcon,"integer",1,size=4)
	miniStreamCutoff <- readBin(rcon,"integer",1,size=4)
	firstMinifatSector <- readBin(rcon,"integer",1,size=4)
	minifatSectors <- readBin(rcon,"integer",1,size=4)
	firstDifatSector <- readBin(rcon,"integer",1,size=4)
	difatSectors <- readBin(rcon,"integer",1,size=4)
	initialDifat <- readBin(rcon,"integer",min(fatSectors,109),size=4)
	on.exit()
	list(majorVersion=majorVersion,
		 minorVersion=minorVersion,
		 sectorSize=sectorSize,
		 minisectorSize=minisectorSize,
		 dirSize=dirSize,
		 fatSectors=fatSectors,
		 firstDirectorySector=firstDirectorySector,
		 signatureNumber=signatureNumber,
		 miniStreamCutoff=miniStreamCutoff,
		 firstMinifatSector=firstMinifatSector,
		 minifatSectors=minifatSectors,
		 firstDifatSector=firstDifatSector,
		 difatSectors=difatSectors,
		 initialDifat=initialDifat)
}

# Extracs a sequence of linked indices in order from a CFBF FAT chain
cfbf_getFatChain <- function(fatTable,firstIndex) {
	nextIndex <- firstIndex
	indexVec <- nextIndexVec <- c()
	while(any(fatTable$Index==nextIndex)) {
		rel <- which(fatTable$Index==nextIndex)
		indexVec <- c(indexVec,nextIndex)
		nextIndex <- fatTable$NextIndex[rel]
		nextIndexVec <- c(nextIndexVec,nextIndex)
	}
	data.frame(Index=indexVec,NextIndex=nextIndexVec)
}

# Read a single row of the CFBF directory object
cfbf_readDirectoryEntry <- function(rcon) {
	on.exit(close(rcon))

	nameBytes <- readBin(rcon,"raw",64)
	nameLength <- readBin(rcon,"integer",1,size=2,signed=FALSE)
	objectType <- readBin(rcon,"integer",1,size=1,signed=FALSE)
	stopifnot(objectType%in%c(0,1,2,5))
	if (objectType==0) {
		readBin(rcon,"raw",128-64-2-1)
		on.exit()
		return(data.frame())
	}
	name <- rawToChar(nameBytes[seq(1,(nameLength-2),by=2)])
	colorFlag <- readBin(rcon,"integer",1,size=1,signed=FALSE)
	stopifnot(colorFlag%in%c(0,1))
	if (colorFlag==0) { color <- "red" }
	else { color <- "black" }
	leftSibling <- readBin(rcon,"integer",1,size=4)
	rightSibling <- readBin(rcon,"integer",1,size=4)
	child <- readBin(rcon,"integer",1,size=4)
	class <- paste0(as.character(as.hexmode(as.numeric(
		readBin(rcon,"raw",16)
	))),collapse="")
	state <- readBin(rcon,"integer",1,size=4)
	creationTime <- paste0(as.character(as.hexmode(as.numeric(
		readBin(rcon,"raw",8)
	))),collapse="")
	modifiedTime <- paste0(as.character(as.hexmode(as.numeric(
		readBin(rcon,"raw",8)
	))),collapse="")
	startingSector <- readBin(rcon,"integer",1,size=4)
	streamSize <- readBin(rcon,"integer",1,size=4)
	readBin(rcon,"integer",1,size=4)

	on.exit()
	data.frame(name=name, objectType=objectType, color=color,
			   leftSibling=leftSibling, rightSibling=rightSibling, child=child,
			   class=class, state=state, creationTime=creationTime,
			   modifiedTime=modifiedTime, startingSector=startingSector,
			   streamSize=streamSize)
}

# Parse a full CFBF object, including header, directory, FAT table and
# miniFAT table and sector indices
cfbf_parseFile <- function(rcon) {
	cfbfHeader <- cfbf_readHeader(rcon)

	nextDifatSector <- cfbfHeader$firstDifatSector
	fatTable <- data.frame()
	difatTable <- data.frame(sector=cfbfHeader$initialDifat,expand=TRUE)
	while(any(difatTable$expand)) {
		for (difatRow in which(difatTable$expand)) {
			seek(rcon,(difatTable$sector[difatRow]+1)*cfbfHeader$sectorSize)
			fatIndices <- nrow(fatTable):(nrow(fatTable)+127)
			fatTable <- rbind(fatTable,
							  data.frame(Index=fatIndices,
							  		   NextIndex=readBin(rcon,"integer",128,size=4)))
			difatTable$expand[difatRow] <- FALSE

			if (nextDifatSector != -2) {
				moreDifat <- cfbf_getFatChain(fatTable,nextDifatSector)
				nextDifatSector <- rev(moreDifat$NextIndex)[1]
				difatTable <- rbind(difatTable,data.frame(sector=moreDifat$Index,expand=TRUE))
			}
		}
	}

	minifatSectors <- cfbf_getFatChain(fatTable,cfbfHeader$firstMinifatSector)

	minifatTable <- data.frame()
	for (sector in minifatSectors$Index) {
		seek(rcon,(sector+1)*cfbfHeader$sectorSize)
		minifatIndices <- nrow(minifatTable):(nrow(minifatTable)+127)
		minifatTable <- rbind(minifatTable,
							  data.frame(Index=minifatIndices,
							  		   NextIndex=readBin(rcon,"integer",128,size=4)))
	}


	directorySectors <- cfbf_getFatChain(fatTable,cfbfHeader$firstDirectorySector)

	directory <- data.frame()
	for (sector in directorySectors$Index) {
		seek(rcon,(sector+1)*cfbfHeader$sectorSize)
		for (entry in 1:4) {
			directory <- rbind(directory,cfbf_readDirectoryEntry(rcon))
		}
	}

	ministreamSectors <- cfbf_getFatChain(fatTable,directory$startingSector[[1]])

	directory$parent <- NA
	directory$path <- NA
	directory$expand <- FALSE
	directory$sibexpand <- FALSE
	directory$parent[[1]] <- -1
	directory$expand[[1]] <- TRUE
	while (any(directory$expand==TRUE)) {
		expander <- which(directory$expand==TRUE)[1]
		if (directory$child[expander]>=0) {
			directory$parent[directory$child[expander]+1] <- expander-1
			directory$expand[directory$child[expander]+1] <- TRUE
			directory$sibexpand[directory$child[expander]+1] <- TRUE
		}
		directory$expand[expander] <- FALSE

		while (any(directory$sibexpand)) {
			sibexpander <- which(directory$sibexpand)[1]
			if (directory$leftSibling[sibexpander]>0) {
				directory$parent[directory$leftSibling[sibexpander]+1] <- expander-1
				directory$expand[directory$leftSibling[sibexpander]+1] <- TRUE
				directory$sibexpand[directory$leftSibling[sibexpander]+1] <- TRUE
			}
			if (directory$rightSibling[sibexpander]>0) {
				directory$parent[directory$rightSibling[sibexpander]+1] <- expander-1
				directory$expand[directory$rightSibling[sibexpander]+1] <- TRUE
				directory$sibexpand[directory$rightSibling[sibexpander]+1] <- TRUE
			}
			directory$sibexpand[sibexpander] <- FALSE
		}
	}
	directory$expand <- NULL
	directory$sibexpand <- NULL

	newHeader <-
		list(majorVersion=cfbfHeader$majorVersion,
			 minorVersion=cfbfHeader$minorVersion,
			 sectorSize=cfbfHeader$sectorSize,
			 minisectorSize=cfbfHeader$minisectorSize,
			 signatureNumber=cfbfHeader$signatureNumber,
			 miniStreamCutoff=cfbfHeader$miniStreamCutoff)

	list(header=newHeader,directory=directory,fatTable=fatTable,
		 minifatSectors=minifatSectors,minifatTable=minifatTable,
		 ministreamSectors=ministreamSectors)
}

# Retrieve a directory entry from a CFBF directory using the object "path
cfbf_getDirectoryEntry <- function(directory,path,root=0) {
	if (length(path)==0) { stop("Unable to locate specified directory path") }
	nextIndex <- which(directory$parent==root & directory$name==path[[1]])
	if (length(nextIndex)!=1) { stop("Unable to locate specified directory path") }
	if (length(path)==1) { return(as.list(directory[nextIndex,])) }
	else { return(cfbf_getDirectoryEntry(directory,path[-1],root=(nextIndex-1))) }
}

# Get a single CFBF ministream sector
cfbf_getMinistreamSector <- function(rcon,minisector,cfbf) {
	minisector <- minisector
	miniPerSector <- cfbf$header$sectorSize/cfbf$header$minisectorSize
	sector <- cfbf$ministreamSectors$Index[1+floor(minisector/miniPerSector)]
	miniOff <- minisector%%miniPerSector
	seek(rcon,(sector+1)*cfbf$header$sectorSize+miniOff*cfbf$header$minisectorSize)
	readBin(rcon,"raw",cfbf$header$minisectorSize)
}

# Retrieve a particular object from a CFBF file using the object "path"
cfbf_getObject <- function(rcon,cfbf,path) {
	entry <- cfbf_getDirectoryEntry(cfbf$directory,path)

	stream <- c()
	if (entry$streamSize>cfbf$header$miniStreamCutoff) {
		currentSectors <- cfbf_getFatChain(cfbf$fatTable,entry$startingSector)
		for (sector in currentSectors$Index) {
			seek(rcon,(sector+1)*cfbf$header$sectorSize)
			stream <- c(stream,readBin(rcon,"raw",cfbf$header$sectorSize))
		}
	} else {
		currentMinisectors <- cfbf_getFatChain(cfbf$minifatTable,entry$startingSector)
		for (minisector in currentMinisectors$Index) {
			stream <- c(stream,cfbf_getMinistreamSector(rcon,minisector,cfbf))
		}
	}
	stream <- stream[seq_len(entry$streamSize)]
	stream
}

# Read a string encoded as two-byte (16-bit) binary data
cfbf_readTwoByteString <- function(tcon) {
	stringLength <- readBin(tcon,"integer",1,size=2,signed=TRUE,endian="little")
	if (stringLength==0) { return("") }
	stringVector <- readBin(tcon,"raw",stringLength)
	rawToChar(stringVector[seq(1,stringLength,by=2)])
}
